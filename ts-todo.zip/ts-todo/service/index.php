<?php
/*
    service.php
*/

date_default_timezone_set("Europe/Stockholm");

define('DB_HOST',  'localhost');
define('DB_NAME', 'todo');
define('DB_USER', 'root');
define('DB_PASS', 'segdeg');

require_once "db.inc";
require_once "action.inc";

$method = $_SERVER['REQUEST_METHOD'];
if ($method == 'POST') {
    $method = $_SERVER['REQUEST_METHOD'];
    $json = file_get_contents('php://input');
    $data =  json_decode($json);
    $action= $data->_action;
    $api = new Action(DB_HOST, DB_NAME, DB_USER, DB_PASS);
    echo $api->$action($data);
}
else if ($method == 'GET') {

    if (isset($_GET['_action'])) {
        $action= $_GET['_action'];
        $data = (object) $_GET;
        $api = new Action(DB_HOST, DB_NAME, DB_USER, DB_PASS);
        echo $api->$action($data);
    } else {
        die('NOT ALLOWED' );
    }
}
else {
    die('WRONG METHOD' );
}


?>