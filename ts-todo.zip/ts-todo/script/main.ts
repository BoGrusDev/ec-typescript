import {WebHelper} from './web-helper.js';


/*
    Declaration
    Här deklareas alla variabler som används
*/

let wh = new WebHelper();
const GETURL = "service/index.php?_action=";

enum statusType {all, pending, progress, wait, cancel, complete};

let addInProgress: boolean = false; 
let currentFilter = statusType.all;

//
//Det här är intervace för koppling mellan databasen och classen ToDo;
// Namnen i Interface måste överenstämma med databasens fältnamn
//
interface toDoInterface {
    todo_id : string;
    todo : string;   
    description : string;
    status : string;
}

//    Browser interaction
class Browser {

    showList() {
        let table = document.getElementById("todo-table") as HTMLTableElement; 

        // Remove all rows in the table exet the header
        for(var i = table.rows.length - 1; i > 0; i--) {
            table.deleteRow(i);
        }       
        for (let i=0; i<toDoList.length; i++){
            if (currentFilter == statusType.all ||toDoList[i].status == currentFilter ) {
                let row = table.insertRow(-1);
                let cell1 = row.insertCell(-1);
                //cell1.onclick = this.selectToDo();                    
                cell1.innerHTML = toDoList[i].todo;
                let cell2 = row.insertCell(-1);
                cell2.innerHTML = '<a class="button is-dark is-small eToDo" todo-id="' + toDoList[i].todo_id + '"><span class="icon is-lg"><i class="fas fa-arrow-alt-circle-right"></i></span><span></span></a>';
            }
        }
        wh.eventClassClick('eToDo', toDoItemLoad);
        wh.hide('todo-item-container');
        wh.show('todo-list-container');
    }
    showItem() {
        wh.val('todo', toDo.toDo);
        wh.val('todo-desc', toDo.description);
        wh.val('todo-status', toDo.status);
        wh.hide('todo-list-container');
        wh.show('todo-item-container');
    }
    
    openFilter() {
        wh.addClass('filter-dropdown', 'is-active');
    }

    backToList() {
        addInProgress = false;
        wh.hide('todo-item-container');
        wh.show('todo-list-container');
    }

    toDoItemAdd() {
        addInProgress = true;
        wh.val('todo', ' ');
        wh.val('todo-desc', ' ');
        wh.val('todo-status', '1');
        wh.hide('todo-list-container');
        wh.show('todo-item-container');
    }
}

// Class for the 
class ToDo {
    toDoId : string;
    toDo : string;   
    description : string;
    status : string;

    set(param: toDoInterface) {
        this.toDoId = param.todo_id;
        this.toDo = param.todo;   
        this.description = param.description;
        this.status = param.status;
    }
}

// Array for the Todo list
let toDoList: any;

// Class for the selected or new Todo item
let toDo = new (ToDo);

// Assign Class for Brower interaction
let browser = new Browser();

// Load all to do items and store them in the toDoList array
async function toDoListLoad(): Promise<any> {
    return new Promise((resolve,reject) => {
       
        fetch(GETURL + 'GetList')
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                toDoList = data;
                console.log(toDoList);
                // Set promise to resolve (means all go well)
            })  
            .then(function() {
                browser.showList();
                 // Set promise to resolve (means all go well)
                resolve(true);
            })
            .catch(function (error) {
                // Someting to wrong Set promise to reject and the error message
                reject(error);
            });
    });
}

// Load the selected Todo item from the service and show it on the screen
async function toDoItemLoad(): Promise<any> {
    let todoId = this.getAttribute('todo-id');
    return new Promise((resolve,reject) => {
       
        fetch(GETURL + 'Get&_todo_id=' + todoId)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                toDo.set(data);
                browser.showItem();
                resolve(true);
            })  
            .catch(function (error) {
                reject(error);
            });
    });
}

function toDoItemUpdate() {
  
    var param:any  =  {};
    if (!addInProgress) {
        param._action = "Update";
        param._todo_id = toDo.toDoId;
    } 
    else {
        param._action = "Insert";
    }
    param.todo = wh.val('todo');
    param.description = wh.val('todo-desc');
    param.status = wh.val('todo-status');
    
    fetch("service/", { 
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json; charset=utf-8"
        },
        redirect: "follow",
        referrer: "no-referrer",
        body: JSON.stringify(param)
    }) 
    .then(function (response) {
        return response.json();
    
    }) 
    .then(function (data) {
        addInProgress = false;

            toDoListLoad();
    })
       
    ["catch"](function (error) {
        console.log(error.message);
    });
}

function toDoListFiltrate() {
    currentFilter = this.getAttribute('filter');
    wh.removeClass('filter-dropdown', 'is-active');
    browser.showList();
}

// Add click event for Save changed item

wh.eventClick('eFilter', browser.openFilter);
wh.eventClassClick('eFiltrate', toDoListFiltrate);
wh.eventClick('eAdd', browser.toDoItemAdd);
wh.eventClick('eSaveToDo', toDoItemUpdate);
wh.eventClick('eBack', browser.backToList);

// Function for Init the App
async function initApp(){
    await toDoListLoad()
    .then((res) => {
        //browser.showList(statusType.all);
        console.log("Init OK"); 
    })
    .catch((err) => {
        console.log(err); 
    })
}

// Call the Init of the app
initApp();


/*
// Not Used

class ToDoList {
    
    list: any;
    getURL: string;
    
    constructor(getURL: string) {
        this.getURL = getURL;
    }
   
    async Load(): Promise<any> {
        return new Promise((resolve,reject) => {
            this.load()
            .then((res) => {
                this.list = res;
                resolve(true);
            })
            .catch((err) => {
                console.log("line 30" + err); 
                reject(err);
            });
        });
    }
   
    async load(): Promise<any> {
        return new Promise((resolve,reject) => {
            fetch("service/index.php?_action=GetList")
            //fetch(this.getURL + 'GetList')
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                resolve(data);
            })  
            .catch(function (error) {
                reject(error);
            });
        });
    }
  
}
*/
