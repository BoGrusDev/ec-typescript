System.register(["./web-helper.js"], function (exports_1, context_1) {
    "use strict";
    var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (this && this.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var web_helper_js_1, wh, GETURL, statusType, addInProgress, currentFilter, Browser, ToDo, toDoList, toDo, browser;
    var __moduleName = context_1 && context_1.id;
    // Load all to do items and store them in the toDoList array
    function toDoListLoad() {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        fetch(GETURL + 'GetList')
                            .then(function (response) {
                            return response.json();
                        })
                            .then(function (data) {
                            toDoList = data;
                            console.log(toDoList);
                            // Set promise to resolve (means all go well)
                        })
                            .then(function () {
                            browser.showList();
                            // Set promise to resolve (means all go well)
                            resolve(true);
                        })["catch"](function (error) {
                            // Someting to wrong Set promise to reject and the error message
                            reject(error);
                        });
                    })];
            });
        });
    }
    // Load the selected Todo item from the service and show it on the screen
    function toDoItemLoad() {
        return __awaiter(this, void 0, void 0, function () {
            var todoId;
            return __generator(this, function (_a) {
                todoId = this.getAttribute('todo-id');
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        fetch(GETURL + 'Get&_todo_id=' + todoId)
                            .then(function (response) {
                            return response.json();
                        })
                            .then(function (data) {
                            toDo.set(data);
                            browser.showItem();
                            resolve(true);
                        })["catch"](function (error) {
                            reject(error);
                        });
                    })];
            });
        });
    }
    function toDoItemUpdate() {
        var param = {};
        if (!addInProgress) {
            param._action = "Update";
            param._todo_id = toDo.toDoId;
        }
        else {
            param._action = "Insert";
        }
        param.todo = wh.val('todo');
        param.description = wh.val('todo-desc');
        param.status = wh.val('todo-status');
        fetch("service/", {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json; charset=utf-8"
            },
            redirect: "follow",
            referrer: "no-referrer",
            body: JSON.stringify(param)
        })
            .then(function (response) {
            return response.json();
        })
            .then(function (data) {
            addInProgress = false;
            toDoListLoad();
        })["catch"](function (error) {
            console.log(error.message);
        });
    }
    function toDoListFiltrate() {
        currentFilter = this.getAttribute('filter');
        wh.removeClass('filter-dropdown', 'is-active');
        browser.showList();
    }
    // Function for Init the App
    function initApp() {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, toDoListLoad()
                            .then(function (res) {
                            //browser.showList(statusType.all);
                            console.log("Init OK");
                        })["catch"](function (err) {
                            console.log(err);
                        })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    }
    return {
        setters: [
            function (web_helper_js_1_1) {
                web_helper_js_1 = web_helper_js_1_1;
            }
        ],
        execute: function () {
            /*
                Declaration
                Här deklareas alla variabler som används
            */
            wh = new web_helper_js_1.WebHelper();
            GETURL = "service/index.php?_action=";
            (function (statusType) {
                statusType[statusType["all"] = 0] = "all";
                statusType[statusType["pending"] = 1] = "pending";
                statusType[statusType["progress"] = 2] = "progress";
                statusType[statusType["wait"] = 3] = "wait";
                statusType[statusType["cancel"] = 4] = "cancel";
                statusType[statusType["complete"] = 5] = "complete";
            })(statusType || (statusType = {}));
            ;
            addInProgress = false;
            currentFilter = statusType.all;
            //    Browser interaction
            Browser = /** @class */ (function () {
                function Browser() {
                }
                Browser.prototype.showList = function () {
                    var table = document.getElementById("todo-table");
                    // Remove all rows in the table exet the header
                    for (var i = table.rows.length - 1; i > 0; i--) {
                        table.deleteRow(i);
                    }
                    for (var i_1 = 0; i_1 < toDoList.length; i_1++) {
                        if (currentFilter == statusType.all || toDoList[i_1].status == currentFilter) {
                            var row = table.insertRow(-1);
                            var cell1 = row.insertCell(-1);
                            //cell1.onclick = this.selectToDo();                    
                            cell1.innerHTML = toDoList[i_1].todo;
                            var cell2 = row.insertCell(-1);
                            cell2.innerHTML = '<a class="button is-dark is-small eToDo" todo-id="' + toDoList[i_1].todo_id + '"><span class="icon is-lg"><i class="fas fa-arrow-alt-circle-right"></i></span><span></span></a>';
                        }
                    }
                    wh.eventClassClick('eToDo', toDoItemLoad);
                    wh.hide('todo-item-container');
                    wh.show('todo-list-container');
                };
                Browser.prototype.showItem = function () {
                    wh.val('todo', toDo.toDo);
                    wh.val('todo-desc', toDo.description);
                    wh.val('todo-status', toDo.status);
                    wh.hide('todo-list-container');
                    wh.show('todo-item-container');
                };
                Browser.prototype.openFilter = function () {
                    wh.addClass('filter-dropdown', 'is-active');
                };
                Browser.prototype.backToList = function () {
                    addInProgress = false;
                    wh.hide('todo-item-container');
                    wh.show('todo-list-container');
                };
                Browser.prototype.toDoItemAdd = function () {
                    addInProgress = true;
                    wh.val('todo', ' ');
                    wh.val('todo-desc', ' ');
                    wh.val('todo-status', '1');
                    wh.hide('todo-list-container');
                    wh.show('todo-item-container');
                };
                return Browser;
            }());
            // Class for the 
            ToDo = /** @class */ (function () {
                function ToDo() {
                }
                ToDo.prototype.set = function (param) {
                    this.toDoId = param.todo_id;
                    this.toDo = param.todo;
                    this.description = param.description;
                    this.status = param.status;
                };
                return ToDo;
            }());
            // Class for the selected or new Todo item
            toDo = new (ToDo);
            // Assign Class for Brower interaction
            browser = new Browser();
            // Add click event for Save changed item
            wh.eventClick('eFilter', browser.openFilter);
            wh.eventClassClick('eFiltrate', toDoListFiltrate);
            wh.eventClick('eAdd', browser.toDoItemAdd);
            wh.eventClick('eSaveToDo', toDoItemUpdate);
            wh.eventClick('eBack', browser.backToList);
            // Call the Init of the app
            initApp();
            /*
            // Not Used
            
            class ToDoList {
                
                list: any;
                getURL: string;
                
                constructor(getURL: string) {
                    this.getURL = getURL;
                }
               
                async Load(): Promise<any> {
                    return new Promise((resolve,reject) => {
                        this.load()
                        .then((res) => {
                            this.list = res;
                            resolve(true);
                        })
                        .catch((err) => {
                            console.log("line 30" + err);
                            reject(err);
                        });
                    });
                }
               
                async load(): Promise<any> {
                    return new Promise((resolve,reject) => {
                        fetch("service/index.php?_action=GetList")
                        //fetch(this.getURL + 'GetList')
                        .then(function(response) {
                            return response.json();
                        })
                        .then(function(data) {
                            resolve(data);
                        })
                        .catch(function (error) {
                            reject(error);
                        });
                    });
                }
              
            }
            */
        }
    };
});
