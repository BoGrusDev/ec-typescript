export class WebHelper {

    show(tag) {
        document.getElementById(tag).style.display="block";
    }
    
    hide(tag) {
        document.getElementById(tag).style.display="none";
    }

    html(tag: string, html?: string) {
        if (html)
            document.getElementById(tag).innerHTML = html;
        else 
        return document.getElementById(tag).innerHTML;
    }

    val(tag: string, value?: string) {
        let element:HTMLInputElement =  document.getElementById(tag) as HTMLInputElement;
        if (value)
            element.value = value;
        else 
        return element.value;
    }

    eventClick(tag:string, action: EventListenerOrEventListenerObject) {
        document.getElementById(tag).addEventListener("click", action);
    }

    eventClassClick(class_name:string, action : EventListenerOrEventListenerObject) {
        var classes = document.getElementsByClassName(class_name);
        for (var i = 0; i < classes.length; ++i) {
            classes[i].addEventListener("click", action);
        }
   }
   
   addClass(tag:string, className: string) {
        var element = document.getElementById(tag);
        element.classList.add(className);
   }
   
   removeClass(tag:string, className: string) {
        var element = document.getElementById(tag);
        element.classList.remove(className);
    }
}

