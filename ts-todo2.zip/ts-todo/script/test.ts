// Test




class Team {
    code:string;
    team:string;
    points:number;
    goalsMade:number;
    goalsEntered:number;
    constructor(code: string,team: string, points:number) {
        this.code = code;
        this.team = team;
        this.points = points;
        this.goalsMade = 0;
        this.goalsEntered = 0;
    }
    getPoints() {
        return this.points;
    }
    addResult(goalsMade: number, goalsEntered: number) {
        this.goalsMade += goalsMade;
        this.goalsEntered += goalsEntered;
        if (goalsMade == goalsEntered) 
            this.points += 1;
        else if (goalsMade > goalsEntered) 
            this.points += 3;
    }
    
}

let myTeam = new Team('LE', "Leeds", 23);

myTeam.addResult(3,1);
myTeam.addResult(2,2);
console.log(myTeam.getPoints());








// Default
let teams:Array<team>;
// Alternativ
let teamsArr:team[];


let messages = [];

interface yearInterestInterface {
    amount: number,
    interest: number
}

interface monthPaymentInterface {
    amount: number,
    interest: number,
    month: number;
}

function monthPayment(param: monthPaymentInterface) {
    return (param.amount * param.interest / 100 / 12) + param.amount / param.month / 12;
}

function yearInterest(param: yearInterestInterface) {
    return param.amount * param.interest / 100;
}


let myLoan = {
    name :  "Bengt Bengtsson",
    amount: 100000,
    interest: 15,
    month: 12};

let myYearInterest = yearInterest(myLoan);
let myMonthPayment = monthPayment(myLoan);

document.getElementById('interface').innerHTML = "Ränta: " + myYearInterest.toString() + "% Månadskostnad: " + myMonthPayment;


class Student {
    fullname : string;
    constructor(public firstname, public middleinitial, public lastname) {
        this.fullname = firstname + " " + middleinitial + " " + lastname;
    }
}

interface Person {
    firstname: string;
    lastname: string;
}

function greeter(person : Person) {
    return "Hello, " + person.firstname + " " + person.lastname;
}

var user = new Student("Jane", "M.", "User");

document.body.innerHTML = greeter(user);