System.register([], function (exports_1, context_1) {
    "use strict";
    var WebHelper;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            WebHelper = /** @class */ (function () {
                function WebHelper() {
                }
                WebHelper.prototype.show = function (tag) {
                    document.getElementById(tag).style.display = "block";
                };
                WebHelper.prototype.hide = function (tag) {
                    document.getElementById(tag).style.display = "none";
                };
                WebHelper.prototype.html = function (tag, html) {
                    if (html)
                        document.getElementById(tag).innerHTML = html;
                    else
                        return document.getElementById(tag).innerHTML;
                };
                WebHelper.prototype.val = function (tag, value) {
                    var element = document.getElementById(tag);
                    if (value)
                        element.value = value;
                    else
                        return element.value;
                };
                WebHelper.prototype.eventClick = function (tag, action) {
                    document.getElementById(tag).addEventListener("click", action);
                };
                WebHelper.prototype.eventClassClick = function (class_name, action) {
                    var classes = document.getElementsByClassName(class_name);
                    for (var i = 0; i < classes.length; ++i) {
                        classes[i].addEventListener("click", action);
                    }
                };
                WebHelper.prototype.addClass = function (tag, className) {
                    var element = document.getElementById(tag);
                    element.classList.add(className);
                };
                WebHelper.prototype.removeClass = function (tag, className) {
                    var element = document.getElementById(tag);
                    element.classList.remove(className);
                };
                return WebHelper;
            }());
            exports_1("WebHelper", WebHelper);
        }
    };
});
